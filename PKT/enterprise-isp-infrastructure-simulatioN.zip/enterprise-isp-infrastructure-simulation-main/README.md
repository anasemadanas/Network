# ISP Network Infrastructure Simulation: Enterprise Hub-and-Spoke WAN with Multi-VLAN Core

## 📌 Project Overview
This repository contains a production-grade enterprise network infrastructure simulation designed in **Cisco Packet Tracer**. The architecture models a high-availability **Hub-and-Spoke Wide Area Network (WAN)** topology where a centralized service provider (`ISP_MAIN`) securely interconnects and routes traffic across three physically isolated customer branch sites (`CUST_01`, `CUST_02`, and `CUST_03`). 

Each branch site enforces strict data-link layer segmentation using specialized **Virtual Local Area Networks (VLANs)** to partition departmental traffic.

### 📄 Project Deliverables
* `*.pkt`: The interactive Cisco Packet Tracer simulation topology file.
* `*.pdf`: Comprehensive engineering report detailing complete IP addressing schemas, subinterfaces, ACL implementations, and connectivity verification logs.

---

## 🌐 System Architecture & Topology Design

The network infrastructure is divided into three logical layers: the Core Backbone, the Edge Routing Spokes, and the Departmental LAN Segmentations.

![Network Topology](topology.png)

### 🛠️ Key Technical Implementations

#### 1. Hub-and-Spoke WAN Infrastructure
* **Central Hub (`ISP_MAIN`):** A Cisco 2911 router acting as the central ISP routing matrix, managing backbone communication between all external spokes.
* **Edge Spokes (`CUST_01`, `CUST_02`, `CUST_03`):** Dedicated customer site routers handling localized branch routing and managing ingress/egress traffic.
* **WAN Connectivity:** Inter-router communication is established over point-to-point serial interfaces (simulating leased WAN links) utilizing [Mention protocol here, e.g., Frame Relay / PPP / HDLC / Static routes].

#### 2. Localized Layer 2 Segmentation (Departmental VLANs)
Every branch switch (`CUST_01_SW`, `CUST_02_SW`, `CUST_03_SW`) partitions the network into **4 distinct broadcast domains** to eliminate broad broadcast radiation and tightly secure departmental endpoints:
* **Engineering (`ENG`):** Dedicated high-performance network segment for technical/development hosts (e.g., `ENG_11`, `ENG_12`).
* **Finance (`FIN`):** Highly secure zone isolating accounting and financial systems traffic (e.g., `FIN_11`, `FIN_12`).
* **Support (`SUP`):** Operational segment provisioning localized service and infrastructure support teams (e.g., `SUP_11`, `SUP_12`).
* **Guests / General Users (`GUS`):** Sandboxed network layer for standard users or external client terminals (e.g., `GUS_11`, `GUS_12`).

#### 3. Inter-VLAN Routing & Infrastructure Security
* **Router-on-a-Stick (RoaS):** Branch edge routers utilize 802.1Q encapsulation trunks over a single physical interface, dividing it into virtual subinterfaces matching the respective VLAN IDs to coordinate inter-VLAN routing.
* **Traffic Filtering via ACLs:** Comprehensive **Access Control Lists (ACLs)** are configured on the branch routers to enforce explicit communication policies (e.g., preventing the Guest `GUS` network from pinging or accessing sensitive `FIN` database terminals).
* **Device Hardening:** All structural infrastructure nodes (routers and switches) utilize encrypted credentials, disabled unused interface configurations, and restricted access layers (SSH over VTY lines).

---

## 📊 Infrastructure Layout Blueprint

| Network Node | Interface Type | Role / Function | Configured Subnets / Segments |
| :--- | :--- | :--- | :--- |
| **`ISP_MAIN`** | Cisco 2911 (Serial Core) | Hub Backbone Router | WAN Point-to-Point Transit Paths |
| **`CUST_01` / `02` / `03`** | Cisco 2911 (Edge) | Spoke Layer 3 Gateway | Inter-VLAN Routing Gateway (802.1Q) |
| **`CUST_01_SW` / `02` / `03`** | Cisco 2960 Series | Layer 2 Distribution | Active VLANs: `ENG`, `FIN`, `SUP`, `GUS` |

---

## 🚀 How to Run, Simulate, and Verify

### 1. Analytical Evaluation
Open the `ISP_Project_Report.pdf` file to review exact IP allocations, network matrices, precise subnet masks (`/24`, `/26`, etc.), and detailed step-by-step configuration commands.

### 2. Live Simulation & CLI Analysis
1. Clone this repository locally and open the `.pkt` file inside **Cisco Packet Tracer (v8.0+)**.
2. Open the desktop terminal interface on any host workstation (e.g., `ENG_11`) and verify end-to-end network tracking using standard utility scripts:
```bash
   # Test internal branch Inter-VLAN communication
   ping [Local_FIN_IP_Address]

   # Verify cross-WAN spoke communication through the ISP Hub
   ping [Remote_Site_ENG_IP_Address]
   tracert [Remote_Site_ENG_IP_Address]
